INSERT INTO student (id,firstname, lastname) VALUES
  (102,'jack', 'ma'),
  (103,'Bill', 'Gates'),
  (104,'steve', 'jobs');